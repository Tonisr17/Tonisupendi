# Toni Supendi 

My personal web v2, made with ❤ and NextJs by Toni Supendi. Created at 11/2/2024 21:30 WIB
